#! /bin/sh


LOG=log/process_1.log

while true
do
echo "process is running" >> $LOG
sleep 1500
done

